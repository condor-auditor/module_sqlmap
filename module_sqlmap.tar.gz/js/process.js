$(document).ready(function() {


function list_compress(){
 var action = "list_compress";
     $.ajax({
        method:'POST',
        url:'report/report.php',
        data:{action:action},

        success:function(data){
            var data = JSON.parse(data);
            $("#list_cant_compress").empty();

            if (data == null) {

                var html = '';
                html += '<tr>';
                html += '<td class="pink-text">N.A</td>';
                html += '<td class="green-text">N.A</td>';
                html += '<td class="green-text">N.A</td>';
                html += '<td class="green-text">N.A</td>';
                html += '</tr>';
                $("#loading_compress_generate").removeClass("progress");
                $("#list_cant_compress").append(html);
                $("#list_cant_compress").addClass('animated fadeInLeftBig');           
            }else{

                for (var line in data)
                {
                    var html = '';
                    html += '<tr>';
                    html += '<td class="pink-text">'+data[line].cant+'</td>';
                    html += '<td class="green-text">'+data[line].name_compress+'</td>';
                    html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_compress+"'onclick='return download_compress(this);'><span class='lever'></span></label></div>"+'</td>';
                    html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_compress+"'onclick='return delete_compress(this);'><span class='lever'></span></label></div>"+'</td>';
                    html += '</tr>';
                    $("#loading_compress_generate").removeClass("progress");
                    $("#list_cant_compress").append(html);
                    $("#list_cant_compress").addClass('animated fadeInLeftBig');
                }
            }



        },
        error: function(){
            alert("ocurrio algo, intenta mas tarde");
        }
     });
}
list_compress();
$("#list_all_compress").on('click', function(e){
    e.preventDefault;
    list_compress();

});


load_list_process();

$('#sqlmap_process_running').on('click', function(e){
    load_list_process();
});



$('#create_report_all_log').on('click', function(e){
   e.preventDefault();
   $("#loading_logs_read").addClass("progress");
   var action = "report_all_log";
   $.ajax({
     method:'POST',
     url:'report/report.php',
     data:{action:action},
     success:function(pdf){
        $("#loading_logs_read").removeClass("progress");
        window.open(pdf, '_blank');
    },
    error: function(){
     alert("ocurrio algo, intenta mas tarde");
 }
});
   
   
});



function list_document(){
   var action = "list_document";
   $.ajax({
    method:'POST',
    url:'report/report.php',
    data:{action:action},

    success:function(data){
        var data = JSON.parse(data);
        $("#list_cant_report").empty();


        if (data == null) {
            var html = '';
            html += '<tr>';
            html += '<td class="pink-text">N.A</td>';
            html += '<td class="green-text">N.A</td>';
            html += '<td class="green-text">N.A</td>';
            html += '<td class="green-text">N.A</td>';
            html += '</tr>';
            $("#loading_report_generate").removeClass("progress");
            $("#list_cant_report").append(html);
            $("#list_cant_report").addClass('animated fadeInLeftBig');
        }


        for (var line in data)
        {
            var html = '';
            html += '<tr>';
            html += '<td class="pink-text">'+data[line].cant+'</td>';
            html += '<td class="green-text">'+data[line].name_pdf+'</td>';
            html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_pdf+"'onclick='return download_document(this);'><span class='lever'></span></label></div>"+'</td>';
            html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_pdf+"'onclick='return delete_document(this);'><span class='lever'></span></label></div>"+'</td>';
            html += '</tr>';
            $("#loading_report_generate").removeClass("progress");
            $("#list_cant_report").append(html);
            $("#list_cant_report").addClass('animated fadeInLeftBig');
        }
    },
    error: function(){
        alert("ocurrio algo, intenta mas tarde");
    }
});
}

list_document();

$("#list_all_report_generate").on('click', function(e){
    e.preventDefault;
    list_document();

});



$('#execute_command').on('click', function(e){
   e.preventDefault();
   var command = $('#command_text').val();
   $('#command_text').val('');
   var accion = "execute";

   if (command == '' ) {
    alert("todos los campos son obligatorios");
    return false;
}else{
   $("#loading_command_pid").addClass("progress"); 
   $.ajax({
    method:'POST',
    url:'setting/manage.php',
    data:{accion:accion,command:command},
    success:function(retorno){
        if (retorno == true) {
            $("#list_command_pid").empty();
            load_list_process();
        }else{
            $("#loading_command_pid").removeClass("progress"); 
            alert("no es posible ejecutar esta secuencia de comandos");
        }

    },
    error: function(){
        alert("ocurrio algo, intenta mas tarde");
    }
});
}
return false;
});


});


function install_uninstall_sqlmap(){

    var module = 'install_uninstall';
    $.get('setting/'+module+'.php', function(data) {

        for (var line in data)
        {
            var html = '';
            if (data[line].status == 'N.I') {
                html += '<tr>';
                html += '<td class="pink-text">'+data[line].service+'</td>';
                html += '<td class="red-text">not installed</td>';
                html += '<td>'+"<div class='switch'><label><input type='checkbox' id='install "+data[line].service+"'onclick='return manage_sqlmap(this);'><span class='lever'></span></label></div>"+'</td>';
                html += '</tr>';

                $("#list_install_sqlmap").append(html);
                $("#list_install_sqlmap").addClass('animated fadeInLeftBig');
            }else{
                html += '<tr>';
                html += '<td class="pink-text">'+data[line].service+'</td>';
                html += '<td class="green-text">installed</td>';
                html += '<td>'+"<div class='switch'><label><input type='checkbox' checked id='remove "+data[line].service+"'onclick='return manage_sqlmap(this);'><span class='lever'></span></label></div>"+'</td>';
                html += '</tr>';

                $("#list_install_sqlmap").append(html);
                $("#list_install_sqlmap").addClass('animated fadeInLeftBig');
            }
        }

    }, 'json');
}


function download_compress(item){
     var id = $(item).attr("id");
     window.open("logs/compress/"+id, 'Download');
}

function delete_compress(item){
     var id = $(item).attr("id");
     var action = "delete_compress";
     $.ajax({
        method:'POST',
        url:'report/report.php',
        data:{documento:id, action:action},

        success:function(data){
            var data = JSON.parse(data);
            $("#list_cant_compress").empty();
            for (var line in data)
            {
                var html = '';
                    html += '<tr>';
                    html += '<td class="pink-text">'+data[line].cant+'</td>';
                    html += '<td class="green-text">'+data[line].name_compress+'</td>';
                    html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_compress+"'onclick='return download_compress(this);'><span class='lever'></span></label></div>"+'</td>';
                    html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_compress+"'onclick='return delete_compress(this);'><span class='lever'></span></label></div>"+'</td>';
                    html += '</tr>';
                    $("#loading_compress_generate").removeClass("progress");
                    $("#list_cant_compress").append(html);
                    $("#list_cant_compress").addClass('animated fadeInLeftBig');
            }
        },
        error: function(){
            alert("ocurrio algo, intenta mas tarde");
        }
     });

}

function status_sqlmap(){
    $("#list_service_sqlmap").empty();
    var module = 'status_sqlmap';

    $.get('setting/'+module+'.php', function(data) {
        for (var line in data)
        {
            var html = '';
            if (data[line].status == 'R'  ) {
                html += '<tr>';
                html += '<td class="pink-text">'+data[line].service+'</td>';
                html += '<td class="green-text">Running</td>';
                html += '</tr>';

                $("#list_service_sqlmap").append(html);
                $("#list_service_sqlmap").addClass('animated fadeInLeftBig');
            }else if(data[line].status == 'N.I'){
                html += '<tr>';
                html += '<td class="pink-text">'+"NOT INSTALLED"+'</td>';
                html += '<td class="pink-text">'+"NOT INSTALLED"+'</td>';
                html += '</tr>';
                $("#list_service_sqlmap").append(html);
                $("#list_service_sqlmap").addClass('animated fadeInLeftBig');
            }else{
                html += '<tr>';
                html += '<td class="pink-text">'+data[line].service+'</td>';
                html += '<td class="red-text">stopped</td>';
                html += '</tr>';

                $("#list_service_sqlmap").append(html);
                $("#list_service_sqlmap").addClass('animated fadeInLeftBig');
            }
        }

    }, 'json');

} 

status_sqlmap();
install_uninstall_sqlmap();



/* FUNCION PARA LISTAR TODAS LAS TARJETAS DE RED Y LA FUNCION RECIBE EL PARAMETRO EN DONDE SE MOSTRARA */
function list_all_target(data_posicion) {
    var accion = 'list_all_target';
    $.ajax({
        method:'POST',
        url:'../../tools/wifi/controller_wifi.php',
        data:{accion:accion},
        success:function(data){
            if ((data != '[]')) {
                var lista = JSON.parse(data);
                for (var line in lista)
                {
                    var html = '';
                    html += '<option value="'+lista[line].interface+'">'+lista[line].interface+'</option>';

                    $("#"+data_posicion).append(html);
                    $('select').material_select();
                }
            }else{  
                var html = '';
                html += '<option value="'+lista[line].interface+'">'+lista[line].interface+'</option>';
                $("#"+data_posicion).append(html);
                $("#"+data_posicion).addClass('animated fadeInLeftBig');
                $('select').material_select();
            }

        },
        error: function(){
            alert("ocurrio algo, intenta mas tarde");
        }
    }); 
}

list_all_target("list_all_target_available");

/* FUNCION PARA CAPTURAR ID DE LOS PROCESOS Y MANEJARLOS */

function manage_sqlmap(item){
   $("#loading_process_sqlmap").addClass("progress"); 
   var id = $(item).attr("id");
   if (id == 'remove sqlmap'){
    var accion = 'remove';
    $.ajax({
        method:'POST',
        url:'setting/manage.php',
        data:{accion:accion},

        success:function(retorno){
            $("#loading_process_sqlmap").removeClass("progress");
            if (retorno == 'removed'){
                $("#list_install_sqlmap").empty();
                $("#list_service_sqlmap").empty();
                alert("sqlmap desinstalado correctamente");
                status_sqlmap();
                install_uninstall_sqlmap();
            }else{
                alert("ocurrio algo mientras se ejecutaba la accion");
            }
        },
        error: function(){
            alert("ocurrio algo, intenta mas tarde");
            $("#loading_process_sqlmap").removeClass("progress");
        }
    });
}else if(id == 'install sqlmap'){
    var accion = 'install';
    $.ajax({
        method:'POST',
        url:'setting/manage.php',
        data:{accion:accion},

        success:function(retorno){
            $("#loading_process_sqlmap").removeClass("progress");
            if (retorno == 'not internet') {
                alert("verifica tu conexion a internet");

            }else if (retorno == 'installed'){
                $("#list_install_sqlmap").empty();
                $("#list_service_sqlmap").empty();

                alert("sqlmap se instalo correctamente");
                status_sqlmap();
                install_uninstall_sqlmap();
            }else{
                alert("ocurrio algo mientras se ejecutaba la accion");
            }
        },
        error: function(){
            alert("ocurrio algo, intenta mas tarde");
            $("#loading_process_sqlmap").removeClass("progress");
        }
    });
}

}

/* FUNCION PARA CAPTURAR ID DE LOS PROCESOS Y MANEJARLOS */

function kill_sqlmap(item){
   var id = $(item).attr("id");
   var accion = 'kill';
   $.ajax({
    method:'POST',
    url:'setting/manage.php',
    data:{pid:id, accion:accion},

    success:function(retorno){
        if (retorno == true) {
            load_list_process();
        }
    },
    error: function(){
        alert("ocurrio algo, intenta mas tarde");
    }
});
}



function load_list_process(){
    $("#loading_command_pid").addClass("progress");

    var module = 'monitor_process';
    $.get('setting/'+module+'.php', function(data) {
        $("#list_command_pid").empty();
        status_sqlmap();
        for (var line in data)
        {
            var html = '';
            if (data[line].process == 'N.A') {
                html += '<tr>';
                html += '<td class="pink-text">'+data[line].process+'</td>';
                html += '<td class="pink-text">'+data[line].process+'</td>';
                html += '<td class="pink-text">'+data[line].process+'</td>';
                html += '</tr>';

                $("#loading_command_pid").removeClass("progress");
                $("#list_command_pid").append(html);
                $("#list_command_pid").addClass('animated fadeInLeftBig');
            }else{
                html += '<tr>';
                html += '<td class="pink-text">'+data[line].process+'</td>';
                html += '<td class="green-text">'+data[line].pid+'</td>';
                html += '<td>'+"<div class='switch'><label><input type='checkbox' checked id='"+data[line].pid+"'onclick='return kill_sqlmap(this);'><span class='lever'></span></label></div>"+'</td>';
                html += '</tr>';

                $("#loading_command_pid").removeClass("progress");
                $("#list_command_pid").append(html);
                $("#list_command_pid").addClass('animated fadeInLeftBig');
            }
        }

    }, 'json');
}

function read_log(){
    $("#loading_logs_read").addClass("progress");

    var module = 'logs_read';
    $.get('setting/'+module+'.php', function(data) {
        $("#logs_content").empty();
        for (var line in data)
        {
            var html = '';
            html += '<div class="valign-text"><h6 class="center-align white-text">'+data[line].content+'</h6></div>';
            $("#loading_logs_read").removeClass("progress");
            $("#logs_content").append(html);
            $("#logs_content").addClass('animated fadeInLeftBig');
        }

    }, 'json');
}

setInterval(read_log, 60000);
$('#load_read_logs').on('click', function(e){
    read_log();
});



function download_document(item){
   var id = $(item).attr("id");
   window.open("pdf/"+id, 'Download');
}



function delete_document(item){
   var id = $(item).attr("id");
   var action = "delete_document";
   $.ajax({
    method:'POST',
    url:'report/report.php',
    data:{documento:id, action:action},

    success:function(data){
        var data = JSON.parse(data);
        $("#list_cant_report").empty();
        for (var line in data)
        {
            var html = '';
            html += '<tr>';
            html += '<td class="pink-text">'+data[line].cant+'</td>';
            html += '<td class="green-text">'+data[line].name_pdf+'</td>';
            html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_pdf+"'onclick='return download_document(this);'><span class='lever'></span></label></div>"+'</td>';
            html += '<td>'+"<div class='switch'><label><input type='checkbox' id='"+data[line].name_pdf+"'onclick='return delete_document(this);'><span class='lever'></span></label></div>"+'</td>';
            html += '</tr>';
            $("#loading_report_generate").removeClass("progress");
            $("#list_cant_report").append(html);
            $("#list_cant_report").addClass('animated fadeInLeftBig');
        }
    },
    error: function(){
        alert("ocurrio algo, intenta mas tarde");
    }
});

}


$('.modal').modal();
$('select').material_select();
