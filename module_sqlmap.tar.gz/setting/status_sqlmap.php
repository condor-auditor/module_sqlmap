<?php 
/* 
#proyecto CONDOR es una herramienta de auditoría de red inalámbrica.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 

include_once("../../../system/login_check.php");
include_once("../../../tools/execute/exec.php");
include_once("../__init__.php");

  $query = " sh -c 'if ! hash $path_bin_sqlmap 2>/dev/null; then echo \"no\" ; fi'";
	$salida = exec_condor($query);


    if (!empty($salida)) {
	   $status_service[] = array(
        'service' => "N.I",
        'status' => "N.I"
        );
      echo json_encode($status_service);
      exit();
    }else{
    	$output = exec_condor("pgrep {$path_bin_sqlmap}");
    	if (empty($output)) {
    		$status_service[] = array(
           'service' => $path_bin_sqlmap,
           'status' => "N.R"
        );
    		
    	}else{
    	$status_service[] = array(
           'service' => $path_bin_sqlmap,
           'status' => "R"
           );
    	}

    }

    echo json_encode($status_service);

?>