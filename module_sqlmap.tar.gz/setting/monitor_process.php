<?php
/* 
#proyecto CONDOR es una herramienta de auditoría de red inalámbrica.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 

include_once("../../../system/login_check.php");
include_once("../../../tools/execute/exec.php");
include_once("../__init__.php");


regex_clean($path_log_sqlmap_command_pid);
$services_running = file($path_log_sqlmap_command_pid);
exec_condor("sed -i -e '/_*_/!d' $path_log_sqlmap_command_pid");




    if (empty($services_running)) {
        $status_service[] = array(
            "process"=> "N.A",
            "pid" => "N.A"
        );
        exec_condor("sed -i '/sqlmap/ d' $path_log_service_running"); 
        regex_clean($path_log_service_running);

        echo json_encode($status_service);
        exit();
    }

    foreach($services_running as $service){
        
        $list_unity = explode("_*_", $service);

        $filter_1 =array_filter($list_unity, "strlen");

        $list_total[] = $filter_1;
    }

    foreach ($list_total as  $value) {
    
       $status_service[] = array(
            'process' => $value[0],
            'pid' => $value[1]
            );
    }

    echo json_encode($status_service);
?>