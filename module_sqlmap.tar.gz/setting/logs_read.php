<?php 
/* 
#proyecto CONDOR es una herramienta de auditoría de red inalámbrica.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 

include_once("../../../system/login_check.php");
include_once("../../../tools/execute/exec.php");
include_once("../__init__.php");


$services_running = filesize($path_log_sqlmap);


if ($services_running <= 0) {
    $contente_log[] = array(
        'content' => 'NOT LOGS'
        );
    echo json_encode($contente_log);
    exit();

}elseif ($services_running > 5242880 ) {
    if (!file_exists($path_log_directory_compress_sqlmap)) {
        exec_condor("mkdir $path_log_directory_compress_sqlmap");
    }
    $hoy = date("Y-m-d-H:i:s");
    $ext = $hoy.".tar.gz";
    exec_condor("tar -czf ".$path_log_directory_sqlmap."sqlmap_$ext ".$path_log_sqlmap."");
    exec_condor("cp -rv $path_log_directory_sqlmap*.tar.gz $path_log_directory_compress_sqlmap");
    exec_condor("rm -rf $path_log_directory_sqlmap*.tar.gz");
    exec_condor("cat /dev/null > ".$path_log_sqlmap."");

}



$services_running = file($path_log_sqlmap);

if (empty($services_running)) {
    $contente_log[] = array(
        'content' => 'NOT LOGS'
        );
    echo json_encode($contente_log);
    exit();

}
    foreach($services_running as $service){
    	$contente_log[] = array(
    		'content' => $service."<br>"
    	);
    }
	sleep(3);
    echo json_encode($contente_log);

?>