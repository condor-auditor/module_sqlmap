<?php 
/* 
#proyecto CONDOR es una herramienta de auditoría de red inalámbrica.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 

$module_name="module_sqlmap";
$path_bin_sqlmap = "sqlmap";
$module_version = "1.0";
$module_version_software  ="https://raw.githubusercontent.com/condor-auditor/".$module_name."/master/version";
$path_module_dowload = "https://github.com/condor-auditor/".$module_name.".git";
$module_author = "@sasaga92";
$module_contact = "ssanchezga@ufpso.edu.co";
$path_module_sqlmap = "/usr/share/lighttpd/condor/www/modules/".$module_name;
$path_log_directory_sqlmap = $path_module_sqlmap."/logs/";
$path_log_directory_compress_sqlmap = $path_log_directory_sqlmap."compress/";
$path_log_sqlmap = $path_log_directory_sqlmap."sqlmap.log";
$path_log_list_connect = $path_module_sqlmap."/logs/list_connect.txt";
$path_log_sqlmap_command_pid = $path_module_sqlmap."/logs/command_pid.log";
$path_log_service_running = "/usr/share/lighttpd/condor/logs/SERVICES_RUNNING";
$path_ip_forward = "/proc/sys/net/ipv4/ip_forward";
$path_base = BASE."/modules/".$module_name;
$path_binary_module = "module_sqlmap.tar.gz.gpg";
$name_compress_module = "module_sqlmap.tar.gz";
$module_description = "Sqlmap es una herramienta desarrollada en el lenguaje python y es muy util para hacer inyeccciones sql automatizados. Su objetivo es detectar y aprovechar las vulnerabilidades de inyección SQL en aplicaciones web.";

$link_pag_oficial_sqlmap = "http://sqlmap.org/";
$link_tutorial_sqlmap = "https://www.youtube.com/embed/DT1JCag5buc";
$link_dowload_project = "https://github.com/sqlmapproject/sqlmap";
?>
