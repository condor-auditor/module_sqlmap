<?php 
/* 
#proyecto CONDOR es una herramienta de auditoría de red inalámbrica.
#Autor: Samir Sanchez Garnica (by:sasaga)
#twitter @sasaga92
#
#
#

#    Copyright (C) <2017>  <samir sanchez garnica>

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

*/ 
include_once("../../../system/login_check.php");
include_once("../__init__.php");

$external_ip = exec("curl ident.me");


if ($external_ip != "" ) {
	$version_soft = file($module_version_software);
}else{
	exit();
}

foreach ($version_soft as $value) {
    $a = explode("_*_", $value);
    $filter_1 =array_filter($a, "strlen");
    $list_clean = array_values($filter_1);
    if ((float)$list_clean[0] > (float)$module_version && (float)$list_clean[0] != (float)$module_version) {
	echo "
		  <div id='update_modal_content' class='modal modal-fixed-footer'>
		    <div class='modal-content'>
		      <h4>System Update</h4>
		      <p>Version $list_clean[0] de $module_name disponible,
		      	 $list_clean[1]
		      	 </p>
		    </div>
		    <div class='modal-footer'>
		      <a id='update_software_ok' onclick='return accept_install(this);' class='modal-action modal-close waves-effect waves-green btn-flat '>Download</a>
		    </div>
		  </div> ";
	}
}

?>
